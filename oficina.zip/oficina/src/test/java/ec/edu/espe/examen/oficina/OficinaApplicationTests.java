package ec.edu.espe.examen.oficina;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OficinaApplicationTests {

	@Test
	void contextLoads() {
	}

}
